<?php

declare(strict_types=1);

/*
 * This file is part of the project by AGBOKOUDJO Franck.
 *
 * (c) AGBOKOUDJO Franck <internationaleswebservices@gmail.com>
 * Phone: +229 01 67 25 18 86
 * LinkedIn: https://www.linkedin.com/in/internationales-web-apps-services-120520193/
 * Github: https://github.com/Agbokoudjo/
 * Company: INTERNATIONALES WEB APPS & SERVICES
 *
 * For more information, please feel free to contact the author.
 */

use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;

use function Symfony\Component\DependencyInjection\Loader\Configurator\param;
use function Symfony\Component\DependencyInjection\Loader\Configurator\service;
use Wlindabla\UserBundle\Domain\User\Application\CommandHandler\ApplyEmailVerificationHandler;
use Wlindabla\UserBundle\Domain\User\Application\Manager\UserManagerInterface;
use Wlindabla\UserBundle\Domain\User\Service\CanonicalFieldsUpdater;
use Wlindabla\UserBundle\Domain\User\Service\CanonicalFieldsUpdaterInterface;
use Wlindabla\UserBundle\Domain\User\Service\EmailVerificationInterface;
use Wlindabla\UserBundle\Domain\User\Service\PasswordResetInterface;
use Wlindabla\UserBundle\Infrastructure\Persistance\DoctrineUserManager;
use Wlindabla\UserBundle\Infrastructure\Persistance\UserManagerDoctrineReference;
use Wlindabla\UserBundle\Infrastructure\Routing\WlindablaRouteLoader;
use Wlindabla\UserBundle\Infrastructure\Security\Provider\CacheUserProviderInterface;
use Wlindabla\UserBundle\Infrastructure\Security\Provider\UserProvider;
use Wlindabla\UserBundle\Infrastructure\Service\EmailVerificationService;
use Wlindabla\UserBundle\Infrastructure\Service\PasswordResetService;
use Wlindabla\UserBundle\Infrastructure\Service\SecureTokenService;
use Wlindabla\UserBundle\Infrastructure\Service\UserDuplicateFinderService;
use Wlindabla\UserBundle\Infrastructure\Templating\TemplateRegistry;
use Wlindabla\UserBundle\Infrastructure\Templating\TemplateRegistryInterface;
use Wlindabla\UserBundle\UI\Http\Controller\Admin\AdminFormLoginController;
use Wlindabla\UserBundle\UI\Http\Controller\Admin\UserLogoutController;
use Wlindabla\UserBundle\UI\Http\Controller\EmailVerificationController;
use Wlindabla\UserBundle\UI\Http\Controller\OutcomePageRenderer;
use Wlindabla\UserBundle\UI\Http\Controller\PasswordResetConfirmationController;
use Wlindabla\UserBundle\UI\Http\Controller\PasswordResetRequestController;
use Wlindabla\UserBundle\UI\Http\EventSubscriber\AccessDeniedListener;
use Wlindabla\UserBundle\UI\Http\EventSubscriber\EntityInUseExceptionListener;

return static function (ContainerConfigurator $container): void {
    $services = $container->services()
        ->defaults()
            ->autowire()
            ->autoconfigure();

    $services->set(TemplateRegistry::class)
        ->arg('$templates', '%wlindabla_user.templates%');
    $services->alias(TemplateRegistryInterface::class, TemplateRegistry::class);

    $services->set(CanonicalFieldsUpdater::class);
    $services->alias(CanonicalFieldsUpdaterInterface::class, CanonicalFieldsUpdater::class);
    $services->set(UserDuplicateFinderService::class);

    $services->set(DoctrineUserManager::class);
    $services->alias(UserManagerInterface::class, DoctrineUserManager::class);
    $services->alias(UserManagerDoctrineReference::class, DoctrineUserManager::class);

    $services->set(UserProvider::class)
        ->arg('$expiresAfter', '%wlindabla_user.security.user_cache_ttl%');
    $services->alias(\Symfony\Component\Security\Core\User\UserProviderInterface::class, UserProvider::class);
    $services->alias(CacheUserProviderInterface::class, UserProvider::class);

    // Resolves %parameters% in route names, then routes the enabled modules.
    // Imported by config/routes.php with: $routes->import('.', WlindablaRouteLoader::TYPE)
    $services->set(WlindablaRouteLoader::class)
        ->args([service('parameter_bag'), param('kernel.environment')])
        ->tag('routing.loader');

    $services->set(AdminFormLoginController::class)
        ->arg('$homeRouteName', '%wlindabla_user.routes.home%')
        ->arg('$siteName', '%app.site_name%')
        ->tag('controller.service_arguments');

    $services->set(UserLogoutController::class);

    $services->set(EmailVerificationController::class)
        ->arg('$loginRouteName', '%wlindabla_user.routes.login%')
        ->arg('$homeRouteName', '%wlindabla_user.routes.home%')
        ->tag('controller.service_arguments');

    $services->set(PasswordResetRequestController::class)
        ->arg('$homeRouteName', '%wlindabla_user.routes.home%')
        ->tag('controller.service_arguments');

    $services->set(PasswordResetConfirmationController::class)
        ->tag('controller.service_arguments');

    $services->set(AccessDeniedListener::class);

    $services->set(EntityInUseExceptionListener::class);

    $services->set(EmailVerificationInterface::class,EmailVerificationService::class);

    $services->set(PasswordResetInterface::class,PasswordResetService::class);

    $services->set(OutcomePageRenderer::class)
            ->arg('$loginRouteName', '%wlindabla_user.routes.login%')
            ->arg('$homeRouteName', '%wlindabla_user.routes.home%')
             ->arg('$siteName', '%app.site_name%')
            ;

    $services->set(SecureTokenService::class);

    $services->set(ApplyEmailVerificationHandler::class);
};